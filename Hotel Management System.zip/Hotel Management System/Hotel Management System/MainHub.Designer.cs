﻿namespace Hotel_Management_System
{
    partial class MainHub
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label firstNameLabel;
            System.Windows.Forms.Label lastNameLabel;
            System.Windows.Forms.Label roomLabel;
            System.Windows.Forms.Label firstNameLabel1;
            System.Windows.Forms.Label lastNameLabel1;
            System.Windows.Forms.Label firstNameLabel2;
            System.Windows.Forms.Label lastNameLabel2;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainHub));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Panel4 = new System.Windows.Forms.Panel();
            this.pnlManager = new System.Windows.Forms.Panel();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlRestaraunt = new System.Windows.Forms.Panel();
            this.Label22 = new System.Windows.Forms.Label();
            this.Label19 = new System.Windows.Forms.Label();
            this.Label20 = new System.Windows.Forms.Label();
            this.Label21 = new System.Windows.Forms.Label();
            this.Panel8 = new System.Windows.Forms.Panel();
            this.pnlAdmin = new System.Windows.Forms.Panel();
            this.Label23 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.Panel9 = new System.Windows.Forms.Panel();
            this.Button1 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button19 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnlCheck = new System.Windows.Forms.Panel();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.CheckTime = new System.Windows.Forms.Label();
            this.pnlUserInfo = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.pnlSchedule = new System.Windows.Forms.Panel();
            this.pnlAddSchedule = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.pnlAnnouncements = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.pnlReservations = new System.Windows.Forms.Panel();
            this.button27 = new System.Windows.Forms.Button();
            this.roomTextBox = new System.Windows.Forms.TextBox();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customer_InfoDataSet = new Hotel_Management_System.Customer_InfoDataSet();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.customersDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customersBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.pnlPay = new System.Windows.Forms.Panel();
            this.lastNameTextBox1 = new System.Windows.Forms.TextBox();
            this.billBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.firstNameTextBox1 = new System.Windows.Forms.TextBox();
            this.billDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.menuDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurant_ResorucesDataSet = new Hotel_Management_System.Restaurant_ResorucesDataSet();
            this.customersTableAdapter = new Hotel_Management_System.Customer_InfoDataSetTableAdapters.CustomersTableAdapter();
            this.tableAdapterManager = new Hotel_Management_System.Customer_InfoDataSetTableAdapters.TableAdapterManager();
            this.billTableAdapter = new Hotel_Management_System.Customer_InfoDataSetTableAdapters.BillTableAdapter();
            this.menuTableAdapter = new Hotel_Management_System.Restaurant_ResorucesDataSetTableAdapters.MenuTableAdapter();
            this.tableAdapterManager1 = new Hotel_Management_System.Restaurant_ResorucesDataSetTableAdapters.TableAdapterManager();
            this.inventoryTableAdapter = new Hotel_Management_System.Restaurant_ResorucesDataSetTableAdapters.InventoryTableAdapter();
            this.reservationsTableAdapter = new Hotel_Management_System.Restaurant_ResorucesDataSetTableAdapters.ReservationsTableAdapter();
            this.pnlInventory = new System.Windows.Forms.Panel();
            this.inventoryDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pnlRestReservation = new System.Windows.Forms.Panel();
            this.lastNameTextBox2 = new System.Windows.Forms.TextBox();
            this.reservationsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.firstNameTextBox2 = new System.Windows.Forms.TextBox();
            this.reservationsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Panel6 = new System.Windows.Forms.Panel();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.pnlLobbyCl = new System.Windows.Forms.Panel();
            this.pnlFinances = new System.Windows.Forms.Panel();
            this.financesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hotel_ResourcesDataSet2 = new Hotel_Management_System.Hotel_ResourcesDataSet2();
            this.financesTableAdapter = new Hotel_Management_System.Hotel_ResourcesDataSet2TableAdapters.FinancesTableAdapter();
            this.tableAdapterManager2 = new Hotel_Management_System.Hotel_ResourcesDataSet2TableAdapters.TableAdapterManager();
            this.Button18 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.Button12 = new System.Windows.Forms.Button();
            this.Button17 = new System.Windows.Forms.Button();
            this.Button15 = new System.Windows.Forms.Button();
            this.Button16 = new System.Windows.Forms.Button();
            this.Button9 = new System.Windows.Forms.Button();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.customersBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.pnlEmpInfo = new System.Windows.Forms.Panel();
            this.staffTableAdapter1 = new Hotel_Management_System.Hotel_ResourcesDataSet1TableAdapters.STAFFTableAdapter();
            this.sTAFFBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sTAFFTableAdapter = new Hotel_Management_System.Hotel_ResourcesDataSet2TableAdapters.STAFFTableAdapter();
            this.sTAFFDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label16 = new System.Windows.Forms.Label();
            this.pnlFAQ = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.financesDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            firstNameLabel = new System.Windows.Forms.Label();
            lastNameLabel = new System.Windows.Forms.Label();
            roomLabel = new System.Windows.Forms.Label();
            firstNameLabel1 = new System.Windows.Forms.Label();
            lastNameLabel1 = new System.Windows.Forms.Label();
            firstNameLabel2 = new System.Windows.Forms.Label();
            lastNameLabel2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.pnlManager.SuspendLayout();
            this.pnlRestaraunt.SuspendLayout();
            this.pnlAdmin.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnlCheck.SuspendLayout();
            this.pnlUserInfo.SuspendLayout();
            this.pnlSchedule.SuspendLayout();
            this.pnlAddSchedule.SuspendLayout();
            this.pnlAnnouncements.SuspendLayout();
            this.pnlReservations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customer_InfoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingNavigator)).BeginInit();
            this.customersBindingNavigator.SuspendLayout();
            this.pnlPay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.billBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billDataGridView)).BeginInit();
            this.pnlMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurant_ResorucesDataSet)).BeginInit();
            this.pnlInventory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).BeginInit();
            this.pnlRestReservation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reservationsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationsDataGridView)).BeginInit();
            this.pnlLobbyCl.SuspendLayout();
            this.pnlFinances.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.financesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotel_ResourcesDataSet2)).BeginInit();
            this.pnlEmpInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sTAFFBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTAFFDataGridView)).BeginInit();
            this.pnlFAQ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.financesDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            firstNameLabel.AutoSize = true;
            firstNameLabel.Location = new System.Drawing.Point(172, 364);
            firstNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            firstNameLabel.Name = "firstNameLabel";
            firstNameLabel.Size = new System.Drawing.Size(60, 13);
            firstNameLabel.TabIndex = 1;
            firstNameLabel.Text = "First Name:";
            // 
            // lastNameLabel
            // 
            lastNameLabel.AutoSize = true;
            lastNameLabel.Location = new System.Drawing.Point(417, 364);
            lastNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            lastNameLabel.Name = "lastNameLabel";
            lastNameLabel.Size = new System.Drawing.Size(61, 13);
            lastNameLabel.TabIndex = 3;
            lastNameLabel.Text = "Last Name:";
            // 
            // roomLabel
            // 
            roomLabel.AutoSize = true;
            roomLabel.Location = new System.Drawing.Point(674, 366);
            roomLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            roomLabel.Name = "roomLabel";
            roomLabel.Size = new System.Drawing.Size(38, 13);
            roomLabel.TabIndex = 5;
            roomLabel.Text = "Room:";
            // 
            // firstNameLabel1
            // 
            firstNameLabel1.AutoSize = true;
            firstNameLabel1.Location = new System.Drawing.Point(630, 63);
            firstNameLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            firstNameLabel1.Name = "firstNameLabel1";
            firstNameLabel1.Size = new System.Drawing.Size(60, 13);
            firstNameLabel1.TabIndex = 1;
            firstNameLabel1.Text = "First Name:";
            // 
            // lastNameLabel1
            // 
            lastNameLabel1.AutoSize = true;
            lastNameLabel1.Location = new System.Drawing.Point(630, 94);
            lastNameLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            lastNameLabel1.Name = "lastNameLabel1";
            lastNameLabel1.Size = new System.Drawing.Size(61, 13);
            lastNameLabel1.TabIndex = 3;
            lastNameLabel1.Text = "Last Name:";
            // 
            // firstNameLabel2
            // 
            firstNameLabel2.AutoSize = true;
            firstNameLabel2.Location = new System.Drawing.Point(632, 72);
            firstNameLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            firstNameLabel2.Name = "firstNameLabel2";
            firstNameLabel2.Size = new System.Drawing.Size(60, 13);
            firstNameLabel2.TabIndex = 1;
            firstNameLabel2.Text = "First Name:";
            // 
            // lastNameLabel2
            // 
            lastNameLabel2.AutoSize = true;
            lastNameLabel2.Location = new System.Drawing.Point(631, 118);
            lastNameLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            lastNameLabel2.Name = "lastNameLabel2";
            lastNameLabel2.Size = new System.Drawing.Size(61, 13);
            lastNameLabel2.TabIndex = 3;
            lastNameLabel2.Text = "Last Name:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.Label4);
            this.panel1.Controls.Add(this.Label2);
            this.panel1.Controls.Add(this.Label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1372, 137);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(149, 136);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1012, 528);
            this.panel5.TabIndex = 11;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Dock = System.Windows.Forms.DockStyle.Right;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label4.Location = new System.Drawing.Point(1212, 0);
            this.Label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(76, 17);
            this.Label4.TabIndex = 10;
            this.Label4.Text = "00:00 XM";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label2.Location = new System.Drawing.Point(0, 0);
            this.Label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(0, 17);
            this.Label2.TabIndex = 8;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label3.Location = new System.Drawing.Point(1288, 0);
            this.Label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(84, 17);
            this.Label3.TabIndex = 9;
            this.Label3.Text = "MM/DD/YY";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(467, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(468, 108);
            this.label1.TabIndex = 1;
            this.label1.Text = "Hotelinator";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(508, 279);
            this.Label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(72, 13);
            this.Label7.TabIndex = 26;
            this.Label7.Text = "Check-In/Out";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(204, 279);
            this.Label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(52, 13);
            this.Label6.TabIndex = 25;
            this.Label6.Text = "Schedule";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(157, 146);
            this.Label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(44, 13);
            this.Label5.TabIndex = 22;
            this.Label5.Text = "General";
            // 
            // Panel4
            // 
            this.Panel4.BackColor = System.Drawing.Color.DimGray;
            this.Panel4.Location = new System.Drawing.Point(159, 167);
            this.Panel4.Margin = new System.Windows.Forms.Padding(2);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(911, 8);
            this.Panel4.TabIndex = 21;
            // 
            // pnlManager
            // 
            this.pnlManager.Controls.Add(this.Label11);
            this.pnlManager.Controls.Add(this.Button9);
            this.pnlManager.Controls.Add(this.Label8);
            this.pnlManager.Controls.Add(this.Button7);
            this.pnlManager.Controls.Add(this.Label9);
            this.pnlManager.Controls.Add(this.panel2);
            this.pnlManager.Location = new System.Drawing.Point(151, 303);
            this.pnlManager.Margin = new System.Windows.Forms.Padding(2);
            this.pnlManager.Name = "pnlManager";
            this.pnlManager.Size = new System.Drawing.Size(790, 285);
            this.pnlManager.TabIndex = 20;
            this.pnlManager.Visible = false;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(347, 138);
            this.Label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(92, 13);
            this.Label11.TabIndex = 26;
            this.Label11.Text = "Manage Finances";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(40, 135);
            this.Label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(79, 13);
            this.Label8.TabIndex = 22;
            this.Label8.Text = "Employee Data";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(8, 6);
            this.Label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(71, 13);
            this.Label9.TabIndex = 20;
            this.Label9.Text = "Special Tools";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(10, 26);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(910, 8);
            this.panel2.TabIndex = 19;
            // 
            // pnlRestaraunt
            // 
            this.pnlRestaraunt.Controls.Add(this.Label22);
            this.pnlRestaraunt.Controls.Add(this.Button17);
            this.pnlRestaraunt.Controls.Add(this.Label19);
            this.pnlRestaraunt.Controls.Add(this.Button15);
            this.pnlRestaraunt.Controls.Add(this.Label20);
            this.pnlRestaraunt.Controls.Add(this.Button16);
            this.pnlRestaraunt.Controls.Add(this.Label21);
            this.pnlRestaraunt.Controls.Add(this.Panel8);
            this.pnlRestaraunt.Location = new System.Drawing.Point(151, 303);
            this.pnlRestaraunt.Margin = new System.Windows.Forms.Padding(2);
            this.pnlRestaraunt.Name = "pnlRestaraunt";
            this.pnlRestaraunt.Size = new System.Drawing.Size(790, 285);
            this.pnlRestaraunt.TabIndex = 31;
            this.pnlRestaraunt.Visible = false;
            // 
            // Label22
            // 
            this.Label22.AutoSize = true;
            this.Label22.Location = new System.Drawing.Point(645, 145);
            this.Label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(69, 13);
            this.Label22.TabIndex = 32;
            this.Label22.Text = "Reservations";
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(376, 145);
            this.Label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(34, 13);
            this.Label19.TabIndex = 30;
            this.Label19.Text = "Menu";
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Location = new System.Drawing.Point(56, 138);
            this.Label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(51, 13);
            this.Label20.TabIndex = 28;
            this.Label20.Text = "Inventory";
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Location = new System.Drawing.Point(8, 9);
            this.Label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(71, 13);
            this.Label21.TabIndex = 26;
            this.Label21.Text = "Special Tools";
            // 
            // Panel8
            // 
            this.Panel8.BackColor = System.Drawing.Color.DimGray;
            this.Panel8.Location = new System.Drawing.Point(10, 29);
            this.Panel8.Margin = new System.Windows.Forms.Padding(2);
            this.Panel8.Name = "Panel8";
            this.Panel8.Size = new System.Drawing.Size(742, 8);
            this.Panel8.TabIndex = 25;
            // 
            // pnlAdmin
            // 
            this.pnlAdmin.Controls.Add(this.Label23);
            this.pnlAdmin.Controls.Add(this.Button18);
            this.pnlAdmin.Controls.Add(this.Label24);
            this.pnlAdmin.Controls.Add(this.Panel9);
            this.pnlAdmin.Location = new System.Drawing.Point(151, 303);
            this.pnlAdmin.Margin = new System.Windows.Forms.Padding(2);
            this.pnlAdmin.Name = "pnlAdmin";
            this.pnlAdmin.Size = new System.Drawing.Size(790, 285);
            this.pnlAdmin.TabIndex = 33;
            this.pnlAdmin.Visible = false;
            // 
            // Label23
            // 
            this.Label23.AutoSize = true;
            this.Label23.Location = new System.Drawing.Point(47, 139);
            this.Label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(71, 13);
            this.Label23.TabIndex = 32;
            this.Label23.Text = "Apply Update";
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Location = new System.Drawing.Point(8, 10);
            this.Label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(71, 13);
            this.Label24.TabIndex = 30;
            this.Label24.Text = "Special Tools";
            // 
            // Panel9
            // 
            this.Panel9.BackColor = System.Drawing.Color.DimGray;
            this.Panel9.Location = new System.Drawing.Point(10, 30);
            this.Panel9.Margin = new System.Windows.Forms.Padding(2);
            this.Panel9.Name = "Panel9";
            this.Panel9.Size = new System.Drawing.Size(742, 8);
            this.Panel9.TabIndex = 29;
            // 
            // Button1
            // 
            this.Button1.FlatAppearance.BorderSize = 0;
            this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Button1.Location = new System.Drawing.Point(0, 73);
            this.Button1.Margin = new System.Windows.Forms.Padding(2);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(150, 40);
            this.Button1.TabIndex = 0;
            this.Button1.Text = "Announcements";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Button2
            // 
            this.Button2.FlatAppearance.BorderSize = 0;
            this.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Button2.Location = new System.Drawing.Point(0, 110);
            this.Button2.Margin = new System.Windows.Forms.Padding(2);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(150, 36);
            this.Button2.TabIndex = 1;
            this.Button2.Text = "User Info";
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Button3
            // 
            this.Button3.FlatAppearance.BorderSize = 0;
            this.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Button3.Location = new System.Drawing.Point(0, 145);
            this.Button3.Margin = new System.Windows.Forms.Padding(2);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(150, 33);
            this.Button3.TabIndex = 2;
            this.Button3.Text = "Logout";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Button4
            // 
            this.Button4.FlatAppearance.BorderSize = 0;
            this.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Button4.Location = new System.Drawing.Point(0, 338);
            this.Button4.Margin = new System.Windows.Forms.Padding(2);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(150, 27);
            this.Button4.TabIndex = 3;
            this.Button4.Text = "Help/FAQ";
            this.Button4.UseVisualStyleBackColor = true;
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Button19
            // 
            this.Button19.FlatAppearance.BorderSize = 0;
            this.Button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Button19.Location = new System.Drawing.Point(0, 39);
            this.Button19.Margin = new System.Windows.Forms.Padding(2);
            this.Button19.Name = "Button19";
            this.Button19.Size = new System.Drawing.Size(150, 40);
            this.Button19.TabIndex = 4;
            this.Button19.Text = "Main";
            this.Button19.UseVisualStyleBackColor = true;
            this.Button19.Click += new System.EventHandler(this.Button19_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Navy;
            this.panel3.Controls.Add(this.Button19);
            this.panel3.Controls.Add(this.Button4);
            this.panel3.Controls.Add(this.Button3);
            this.panel3.Controls.Add(this.Button2);
            this.panel3.Controls.Add(this.Button1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 162);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(150, 615);
            this.panel3.TabIndex = 7;
            // 
            // pnlCheck
            // 
            this.pnlCheck.Controls.Add(this.button24);
            this.pnlCheck.Controls.Add(this.button23);
            this.pnlCheck.Controls.Add(this.CheckTime);
            this.pnlCheck.Location = new System.Drawing.Point(152, 160);
            this.pnlCheck.Margin = new System.Windows.Forms.Padding(2);
            this.pnlCheck.Name = "pnlCheck";
            this.pnlCheck.Size = new System.Drawing.Size(1020, 541);
            this.pnlCheck.TabIndex = 34;
            this.pnlCheck.Visible = false;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(457, 256);
            this.button24.Margin = new System.Windows.Forms.Padding(2);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(116, 57);
            this.button24.TabIndex = 2;
            this.button24.Text = "Check-Out";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(261, 256);
            this.button23.Margin = new System.Windows.Forms.Padding(2);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(116, 57);
            this.button23.TabIndex = 1;
            this.button23.Text = "Check-In";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // CheckTime
            // 
            this.CheckTime.AutoSize = true;
            this.CheckTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckTime.Location = new System.Drawing.Point(256, 121);
            this.CheckTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CheckTime.Name = "CheckTime";
            this.CheckTime.Size = new System.Drawing.Size(0, 73);
            this.CheckTime.TabIndex = 0;
            // 
            // pnlUserInfo
            // 
            this.pnlUserInfo.Controls.Add(this.textBox1);
            this.pnlUserInfo.Controls.Add(this.label33);
            this.pnlUserInfo.Controls.Add(this.label32);
            this.pnlUserInfo.Controls.Add(this.label26);
            this.pnlUserInfo.Controls.Add(this.button21);
            this.pnlUserInfo.Controls.Add(this.textBox6);
            this.pnlUserInfo.Controls.Add(this.label31);
            this.pnlUserInfo.Controls.Add(this.textBox5);
            this.pnlUserInfo.Controls.Add(this.label30);
            this.pnlUserInfo.Controls.Add(this.textBox4);
            this.pnlUserInfo.Controls.Add(this.label29);
            this.pnlUserInfo.Controls.Add(this.textBox3);
            this.pnlUserInfo.Controls.Add(this.label28);
            this.pnlUserInfo.Controls.Add(this.textBox2);
            this.pnlUserInfo.Controls.Add(this.label27);
            this.pnlUserInfo.Location = new System.Drawing.Point(152, 162);
            this.pnlUserInfo.Margin = new System.Windows.Forms.Padding(2);
            this.pnlUserInfo.Name = "pnlUserInfo";
            this.pnlUserInfo.Size = new System.Drawing.Size(917, 522);
            this.pnlUserInfo.TabIndex = 1;
            this.pnlUserInfo.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(278, 109);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(258, 20);
            this.textBox1.TabIndex = 16;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(215, 111);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(21, 13);
            this.label33.TabIndex = 15;
            this.label33.Text = "ID:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(313, 50);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(317, 20);
            this.label32.TabIndex = 14;
            this.label32.Text = "View and Update your Account Details here";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(362, 9);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(208, 37);
            this.label26.TabIndex = 13;
            this.label26.Text = "Account Info";
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(646, 184);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(97, 63);
            this.button21.TabIndex = 12;
            this.button21.Text = "Update";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(278, 352);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(258, 20);
            this.textBox6.TabIndex = 11;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(179, 354);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(56, 13);
            this.label31.TabIndex = 10;
            this.label31.Text = "Password:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(278, 303);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(258, 20);
            this.textBox5.TabIndex = 9;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(176, 306);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(58, 13);
            this.label30.TabIndex = 8;
            this.label30.Text = "Username:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(278, 258);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(258, 20);
            this.textBox4.TabIndex = 7;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(174, 260);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(61, 13);
            this.label29.TabIndex = 6;
            this.label29.Text = "Last Name:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(278, 208);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(258, 20);
            this.textBox3.TabIndex = 5;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(174, 210);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 13);
            this.label28.TabIndex = 4;
            this.label28.Text = "First Name:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(278, 156);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(258, 20);
            this.textBox2.TabIndex = 3;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(188, 158);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 13);
            this.label27.TabIndex = 2;
            this.label27.Text = "Position:";
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(700, 184);
            this.button22.Margin = new System.Windows.Forms.Padding(2);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(97, 63);
            this.button22.TabIndex = 12;
            this.button22.Text = "Add to Schedule";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Visible = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(385, 9);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(157, 37);
            this.label36.TabIndex = 13;
            this.label36.Text = "Schedule";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(313, 50);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(317, 20);
            this.label35.TabIndex = 14;
            this.label35.Text = "View and Update your Account Details here";
            // 
            // pnlSchedule
            // 
            this.pnlSchedule.Controls.Add(this.pnlAddSchedule);
            this.pnlSchedule.Controls.Add(this.listBox1);
            this.pnlSchedule.Controls.Add(this.monthCalendar1);
            this.pnlSchedule.Controls.Add(this.label35);
            this.pnlSchedule.Controls.Add(this.label36);
            this.pnlSchedule.Controls.Add(this.button22);
            this.pnlSchedule.Location = new System.Drawing.Point(150, 162);
            this.pnlSchedule.Margin = new System.Windows.Forms.Padding(2);
            this.pnlSchedule.Name = "pnlSchedule";
            this.pnlSchedule.Size = new System.Drawing.Size(917, 522);
            this.pnlSchedule.TabIndex = 17;
            this.pnlSchedule.Visible = false;
            // 
            // pnlAddSchedule
            // 
            this.pnlAddSchedule.Controls.Add(this.dateTimePicker1);
            this.pnlAddSchedule.Controls.Add(this.button26);
            this.pnlAddSchedule.Controls.Add(this.button25);
            this.pnlAddSchedule.Controls.Add(this.label41);
            this.pnlAddSchedule.Controls.Add(this.textBox12);
            this.pnlAddSchedule.Controls.Add(this.label40);
            this.pnlAddSchedule.Controls.Add(this.textBox11);
            this.pnlAddSchedule.Controls.Add(this.label39);
            this.pnlAddSchedule.Controls.Add(this.textBox10);
            this.pnlAddSchedule.Controls.Add(this.label38);
            this.pnlAddSchedule.Controls.Add(this.textBox9);
            this.pnlAddSchedule.Controls.Add(this.label37);
            this.pnlAddSchedule.Controls.Add(this.textBox8);
            this.pnlAddSchedule.Controls.Add(this.label34);
            this.pnlAddSchedule.Location = new System.Drawing.Point(273, 374);
            this.pnlAddSchedule.Margin = new System.Windows.Forms.Padding(2);
            this.pnlAddSchedule.Name = "pnlAddSchedule";
            this.pnlAddSchedule.Size = new System.Drawing.Size(350, 172);
            this.pnlAddSchedule.TabIndex = 17;
            this.pnlAddSchedule.Visible = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(86, 33);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(103, 20);
            this.dateTimePicker1.TabIndex = 14;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(210, 132);
            this.button26.Margin = new System.Windows.Forms.Padding(2);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(56, 19);
            this.button26.TabIndex = 13;
            this.button26.Text = "Clear";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(66, 132);
            this.button25.Margin = new System.Windows.Forms.Padding(2);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(56, 19);
            this.button25.TabIndex = 12;
            this.button25.Text = "Add";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(193, 93);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(55, 13);
            this.label41.TabIndex = 11;
            this.label41.Text = "End Time:";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(258, 90);
            this.textBox12.Margin = new System.Windows.Forms.Padding(2);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(76, 20);
            this.textBox12.TabIndex = 10;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(193, 66);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(58, 13);
            this.label40.TabIndex = 9;
            this.label40.Text = "Start Time:";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(258, 63);
            this.textBox11.Margin = new System.Windows.Forms.Padding(2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(76, 20);
            this.textBox11.TabIndex = 8;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(193, 36);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(61, 13);
            this.label39.TabIndex = 7;
            this.label39.Text = "Last Name:";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(258, 33);
            this.textBox10.Margin = new System.Windows.Forms.Padding(2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(76, 20);
            this.textBox10.TabIndex = 6;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(21, 93);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(60, 13);
            this.label38.TabIndex = 5;
            this.label38.Text = "First Name:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(86, 90);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(76, 20);
            this.textBox9.TabIndex = 4;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(21, 66);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(21, 13);
            this.label37.TabIndex = 3;
            this.label37.Text = "ID:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(86, 63);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(76, 20);
            this.textBox8.TabIndex = 2;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(21, 36);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(33, 13);
            this.label34.TabIndex = 1;
            this.label34.Text = "Date:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(506, 130);
            this.listBox1.Margin = new System.Windows.Forms.Padding(2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(177, 212);
            this.listBox1.TabIndex = 16;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(185, 130);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(7);
            this.monthCalendar1.MaxSelectionCount = 1;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 15;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // pnlAnnouncements
            // 
            this.pnlAnnouncements.Controls.Add(this.richTextBox1);
            this.pnlAnnouncements.Controls.Add(this.label42);
            this.pnlAnnouncements.Location = new System.Drawing.Point(151, 136);
            this.pnlAnnouncements.Margin = new System.Windows.Forms.Padding(2);
            this.pnlAnnouncements.Name = "pnlAnnouncements";
            this.pnlAnnouncements.Size = new System.Drawing.Size(998, 548);
            this.pnlAnnouncements.TabIndex = 11;
            this.pnlAnnouncements.Visible = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(122, 74);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(667, 359);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(346, 11);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(198, 29);
            this.label42.TabIndex = 0;
            this.label42.Text = "Announcements";
            // 
            // pnlReservations
            // 
            this.pnlReservations.Controls.Add(this.button27);
            this.pnlReservations.Controls.Add(roomLabel);
            this.pnlReservations.Controls.Add(this.roomTextBox);
            this.pnlReservations.Controls.Add(lastNameLabel);
            this.pnlReservations.Controls.Add(this.lastNameTextBox);
            this.pnlReservations.Controls.Add(firstNameLabel);
            this.pnlReservations.Controls.Add(this.firstNameTextBox);
            this.pnlReservations.Controls.Add(this.customersDataGridView);
            this.pnlReservations.Location = new System.Drawing.Point(151, 161);
            this.pnlReservations.Margin = new System.Windows.Forms.Padding(2);
            this.pnlReservations.Name = "pnlReservations";
            this.pnlReservations.Size = new System.Drawing.Size(1220, 572);
            this.pnlReservations.TabIndex = 3;
            this.pnlReservations.Visible = false;
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(444, 434);
            this.button27.Margin = new System.Windows.Forms.Padding(2);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(120, 61);
            this.button27.TabIndex = 7;
            this.button27.Text = "Customer Check-Out";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // roomTextBox
            // 
            this.roomTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "Room", true));
            this.roomTextBox.Location = new System.Drawing.Point(716, 364);
            this.roomTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.roomTextBox.Name = "roomTextBox";
            this.roomTextBox.Size = new System.Drawing.Size(76, 20);
            this.roomTextBox.TabIndex = 6;
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.customer_InfoDataSet;
            // 
            // customer_InfoDataSet
            // 
            this.customer_InfoDataSet.DataSetName = "Customer_InfoDataSet";
            this.customer_InfoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "LastName", true));
            this.lastNameTextBox.Location = new System.Drawing.Point(482, 362);
            this.lastNameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(76, 20);
            this.lastNameTextBox.TabIndex = 4;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "FirstName", true));
            this.firstNameTextBox.Location = new System.Drawing.Point(237, 362);
            this.firstNameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(76, 20);
            this.firstNameTextBox.TabIndex = 2;
            // 
            // customersDataGridView
            // 
            this.customersDataGridView.AutoGenerateColumns = false;
            this.customersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customersDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13});
            this.customersDataGridView.DataSource = this.customersBindingSource;
            this.customersDataGridView.Location = new System.Drawing.Point(1, 8);
            this.customersDataGridView.Margin = new System.Windows.Forms.Padding(2);
            this.customersDataGridView.Name = "customersDataGridView";
            this.customersDataGridView.RowTemplate.Height = 24;
            this.customersDataGridView.Size = new System.Drawing.Size(993, 297);
            this.customersDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn2.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn3.HeaderText = "LastName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn4.HeaderText = "Address";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "City";
            this.dataGridViewTextBoxColumn5.HeaderText = "City";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "State";
            this.dataGridViewTextBoxColumn6.HeaderText = "State";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ZIP";
            this.dataGridViewTextBoxColumn7.HeaderText = "ZIP";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Phone";
            this.dataGridViewTextBoxColumn8.HeaderText = "Phone";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn9.HeaderText = "Email";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Guests";
            this.dataGridViewTextBoxColumn10.HeaderText = "Guests";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Room";
            this.dataGridViewTextBoxColumn11.HeaderText = "Room";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "CheckIn";
            this.dataGridViewTextBoxColumn12.HeaderText = "CheckIn";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "CheckOut";
            this.dataGridViewTextBoxColumn13.HeaderText = "CheckOut";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // customersBindingNavigator
            // 
            this.customersBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.customersBindingNavigator.BindingSource = this.customersBindingSource;
            this.customersBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.customersBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.customersBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.customersBindingNavigatorSaveItem});
            this.customersBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.customersBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.customersBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.customersBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.customersBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.customersBindingNavigator.Name = "customersBindingNavigator";
            this.customersBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.customersBindingNavigator.Size = new System.Drawing.Size(1372, 25);
            this.customersBindingNavigator.TabIndex = 35;
            this.customersBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(38, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // pnlPay
            // 
            this.pnlPay.Controls.Add(lastNameLabel1);
            this.pnlPay.Controls.Add(this.lastNameTextBox1);
            this.pnlPay.Controls.Add(firstNameLabel1);
            this.pnlPay.Controls.Add(this.firstNameTextBox1);
            this.pnlPay.Controls.Add(this.billDataGridView);
            this.pnlPay.Location = new System.Drawing.Point(152, 158);
            this.pnlPay.Margin = new System.Windows.Forms.Padding(2);
            this.pnlPay.Name = "pnlPay";
            this.pnlPay.Size = new System.Drawing.Size(1220, 569);
            this.pnlPay.TabIndex = 7;
            this.pnlPay.Visible = false;
            // 
            // lastNameTextBox1
            // 
            this.lastNameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.billBindingSource, "LastName", true));
            this.lastNameTextBox1.Location = new System.Drawing.Point(694, 92);
            this.lastNameTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.lastNameTextBox1.Name = "lastNameTextBox1";
            this.lastNameTextBox1.Size = new System.Drawing.Size(76, 20);
            this.lastNameTextBox1.TabIndex = 4;
            // 
            // billBindingSource
            // 
            this.billBindingSource.DataMember = "Bill";
            this.billBindingSource.DataSource = this.customer_InfoDataSet;
            // 
            // firstNameTextBox1
            // 
            this.firstNameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.billBindingSource, "FirstName", true));
            this.firstNameTextBox1.Location = new System.Drawing.Point(694, 60);
            this.firstNameTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.firstNameTextBox1.Name = "firstNameTextBox1";
            this.firstNameTextBox1.Size = new System.Drawing.Size(76, 20);
            this.firstNameTextBox1.TabIndex = 2;
            // 
            // billDataGridView
            // 
            this.billDataGridView.AutoGenerateColumns = false;
            this.billDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.billDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20});
            this.billDataGridView.DataSource = this.billBindingSource;
            this.billDataGridView.Location = new System.Drawing.Point(1, 20);
            this.billDataGridView.Margin = new System.Windows.Forms.Padding(2);
            this.billDataGridView.Name = "billDataGridView";
            this.billDataGridView.RowTemplate.Height = 24;
            this.billDataGridView.Size = new System.Drawing.Size(556, 428);
            this.billDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn14.HeaderText = "ID";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn15.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn16.HeaderText = "LastName";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Bill";
            this.dataGridViewTextBoxColumn17.HeaderText = "Bill";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "PayType";
            this.dataGridViewTextBoxColumn18.HeaderText = "PayType";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "CreditCard";
            this.dataGridViewTextBoxColumn19.HeaderText = "CreditCard";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Status";
            this.dataGridViewTextBoxColumn20.HeaderText = "Status";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // pnlMenu
            // 
            this.pnlMenu.Controls.Add(this.menuDataGridView);
            this.pnlMenu.Location = new System.Drawing.Point(152, 159);
            this.pnlMenu.Margin = new System.Windows.Forms.Padding(2);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(1161, 547);
            this.pnlMenu.TabIndex = 3;
            this.pnlMenu.Visible = false;
            // 
            // menuDataGridView
            // 
            this.menuDataGridView.AutoGenerateColumns = false;
            this.menuDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.menuDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23});
            this.menuDataGridView.DataSource = this.menuBindingSource;
            this.menuDataGridView.Location = new System.Drawing.Point(148, 64);
            this.menuDataGridView.Margin = new System.Windows.Forms.Padding(2);
            this.menuDataGridView.Name = "menuDataGridView";
            this.menuDataGridView.RowTemplate.Height = 24;
            this.menuDataGridView.Size = new System.Drawing.Size(351, 379);
            this.menuDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Food";
            this.dataGridViewTextBoxColumn21.HeaderText = "Food";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn22.HeaderText = "Price";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Ingredients";
            this.dataGridViewTextBoxColumn23.HeaderText = "Ingredients";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // menuBindingSource
            // 
            this.menuBindingSource.DataMember = "Menu";
            this.menuBindingSource.DataSource = this.restaurant_ResorucesDataSet;
            // 
            // restaurant_ResorucesDataSet
            // 
            this.restaurant_ResorucesDataSet.DataSetName = "Restaurant_ResorucesDataSet";
            this.restaurant_ResorucesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BillTableAdapter = this.billTableAdapter;
            this.tableAdapterManager.CustomersTableAdapter = this.customersTableAdapter;
            this.tableAdapterManager.UpdateOrder = Hotel_Management_System.Customer_InfoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // billTableAdapter
            // 
            this.billTableAdapter.ClearBeforeFill = true;
            // 
            // menuTableAdapter
            // 
            this.menuTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.InventoryTableAdapter = this.inventoryTableAdapter;
            this.tableAdapterManager1.MenuTableAdapter = this.menuTableAdapter;
            this.tableAdapterManager1.ReservationsTableAdapter = this.reservationsTableAdapter;
            this.tableAdapterManager1.UpdateOrder = Hotel_Management_System.Restaurant_ResorucesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // inventoryTableAdapter
            // 
            this.inventoryTableAdapter.ClearBeforeFill = true;
            // 
            // reservationsTableAdapter
            // 
            this.reservationsTableAdapter.ClearBeforeFill = true;
            // 
            // pnlInventory
            // 
            this.pnlInventory.Controls.Add(this.inventoryDataGridView);
            this.pnlInventory.Location = new System.Drawing.Point(152, 159);
            this.pnlInventory.Margin = new System.Windows.Forms.Padding(2);
            this.pnlInventory.Name = "pnlInventory";
            this.pnlInventory.Size = new System.Drawing.Size(1128, 568);
            this.pnlInventory.TabIndex = 3;
            this.pnlInventory.Visible = false;
            // 
            // inventoryDataGridView
            // 
            this.inventoryDataGridView.AutoGenerateColumns = false;
            this.inventoryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.inventoryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26});
            this.inventoryDataGridView.DataSource = this.inventoryBindingSource;
            this.inventoryDataGridView.Location = new System.Drawing.Point(63, 5);
            this.inventoryDataGridView.Margin = new System.Windows.Forms.Padding(2);
            this.inventoryDataGridView.Name = "inventoryDataGridView";
            this.inventoryDataGridView.RowTemplate.Height = 24;
            this.inventoryDataGridView.Size = new System.Drawing.Size(370, 436);
            this.inventoryDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Item";
            this.dataGridViewTextBoxColumn24.HeaderText = "Item";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn25.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "Recommended";
            this.dataGridViewTextBoxColumn26.HeaderText = "Recommended";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // inventoryBindingSource
            // 
            this.inventoryBindingSource.DataMember = "Inventory";
            this.inventoryBindingSource.DataSource = this.restaurant_ResorucesDataSet;
            // 
            // pnlRestReservation
            // 
            this.pnlRestReservation.Controls.Add(lastNameLabel2);
            this.pnlRestReservation.Controls.Add(this.lastNameTextBox2);
            this.pnlRestReservation.Controls.Add(firstNameLabel2);
            this.pnlRestReservation.Controls.Add(this.firstNameTextBox2);
            this.pnlRestReservation.Controls.Add(this.reservationsDataGridView);
            this.pnlRestReservation.Location = new System.Drawing.Point(151, 159);
            this.pnlRestReservation.Margin = new System.Windows.Forms.Padding(2);
            this.pnlRestReservation.Name = "pnlRestReservation";
            this.pnlRestReservation.Size = new System.Drawing.Size(1175, 618);
            this.pnlRestReservation.TabIndex = 3;
            this.pnlRestReservation.Visible = false;
            // 
            // lastNameTextBox2
            // 
            this.lastNameTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.reservationsBindingSource, "LastName", true));
            this.lastNameTextBox2.Location = new System.Drawing.Point(695, 115);
            this.lastNameTextBox2.Margin = new System.Windows.Forms.Padding(2);
            this.lastNameTextBox2.Name = "lastNameTextBox2";
            this.lastNameTextBox2.Size = new System.Drawing.Size(76, 20);
            this.lastNameTextBox2.TabIndex = 4;
            // 
            // reservationsBindingSource
            // 
            this.reservationsBindingSource.DataMember = "Reservations";
            this.reservationsBindingSource.DataSource = this.restaurant_ResorucesDataSet;
            // 
            // firstNameTextBox2
            // 
            this.firstNameTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.reservationsBindingSource, "FirstName", true));
            this.firstNameTextBox2.Location = new System.Drawing.Point(697, 69);
            this.firstNameTextBox2.Margin = new System.Windows.Forms.Padding(2);
            this.firstNameTextBox2.Name = "firstNameTextBox2";
            this.firstNameTextBox2.Size = new System.Drawing.Size(76, 20);
            this.firstNameTextBox2.TabIndex = 2;
            // 
            // reservationsDataGridView
            // 
            this.reservationsDataGridView.AutoGenerateColumns = false;
            this.reservationsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reservationsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31});
            this.reservationsDataGridView.DataSource = this.reservationsBindingSource;
            this.reservationsDataGridView.Location = new System.Drawing.Point(73, 28);
            this.reservationsDataGridView.Margin = new System.Windows.Forms.Padding(2);
            this.reservationsDataGridView.Name = "reservationsDataGridView";
            this.reservationsDataGridView.RowTemplate.Height = 24;
            this.reservationsDataGridView.Size = new System.Drawing.Size(491, 434);
            this.reservationsDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "DineDate";
            this.dataGridViewTextBoxColumn27.HeaderText = "DineDate";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "CustID";
            this.dataGridViewTextBoxColumn28.HeaderText = "CustID";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn29.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn30.HeaderText = "LastName";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Arrival";
            this.dataGridViewTextBoxColumn31.HeaderText = "Arrival";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            // 
            // Panel6
            // 
            this.Panel6.BackColor = System.Drawing.Color.DimGray;
            this.Panel6.Location = new System.Drawing.Point(10, 29);
            this.Panel6.Margin = new System.Windows.Forms.Padding(2);
            this.Panel6.Name = "Panel6";
            this.Panel6.Size = new System.Drawing.Size(909, 8);
            this.Panel6.TabIndex = 25;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(8, 9);
            this.Label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(71, 13);
            this.Label15.TabIndex = 26;
            this.Label15.Text = "Special Tools";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(46, 138);
            this.Label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(69, 13);
            this.Label14.TabIndex = 28;
            this.Label14.Text = "Reservations";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(382, 143);
            this.Label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(28, 13);
            this.Label13.TabIndex = 30;
            this.Label13.Text = "FAQ";
            // 
            // pnlLobbyCl
            // 
            this.pnlLobbyCl.Controls.Add(this.Label13);
            this.pnlLobbyCl.Controls.Add(this.Button11);
            this.pnlLobbyCl.Controls.Add(this.Label14);
            this.pnlLobbyCl.Controls.Add(this.Button12);
            this.pnlLobbyCl.Controls.Add(this.Label15);
            this.pnlLobbyCl.Controls.Add(this.Panel6);
            this.pnlLobbyCl.Location = new System.Drawing.Point(151, 303);
            this.pnlLobbyCl.Margin = new System.Windows.Forms.Padding(2);
            this.pnlLobbyCl.Name = "pnlLobbyCl";
            this.pnlLobbyCl.Size = new System.Drawing.Size(920, 348);
            this.pnlLobbyCl.TabIndex = 20;
            this.pnlLobbyCl.Visible = false;
            // 
            // pnlFinances
            // 
            this.pnlFinances.Controls.Add(this.financesDataGridView);
            this.pnlFinances.Location = new System.Drawing.Point(150, 162);
            this.pnlFinances.Name = "pnlFinances";
            this.pnlFinances.Size = new System.Drawing.Size(1210, 474);
            this.pnlFinances.TabIndex = 12;
            this.pnlFinances.Visible = false;
            this.pnlFinances.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlFinances_Paint);
            // 
            // financesBindingSource
            // 
            this.financesBindingSource.DataMember = "Finances";
            this.financesBindingSource.DataSource = this.hotel_ResourcesDataSet2;
            // 
            // hotel_ResourcesDataSet2
            // 
            this.hotel_ResourcesDataSet2.DataSetName = "Hotel_ResourcesDataSet2";
            this.hotel_ResourcesDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // financesTableAdapter
            // 
            this.financesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.AnnouncementsTableAdapter = null;
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.FinancesTableAdapter = this.financesTableAdapter;
            this.tableAdapterManager2.ScheduleTableAdapter = null;
            this.tableAdapterManager2.STAFFTableAdapter = null;
            this.tableAdapterManager2.UpdateOrder = Hotel_Management_System.Hotel_ResourcesDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // Button18
            // 
            this.Button18.BackgroundImage = global::Hotel_Management_System.Properties.Resources._189686;
            this.Button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button18.Location = new System.Drawing.Point(36, 52);
            this.Button18.Margin = new System.Windows.Forms.Padding(2);
            this.Button18.Name = "Button18";
            this.Button18.Size = new System.Drawing.Size(88, 84);
            this.Button18.TabIndex = 31;
            this.Button18.UseVisualStyleBackColor = true;
            // 
            // Button11
            // 
            this.Button11.BackgroundImage = global::Hotel_Management_System.Properties.Resources._50_512;
            this.Button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button11.Location = new System.Drawing.Point(346, 56);
            this.Button11.Margin = new System.Windows.Forms.Padding(2);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(88, 84);
            this.Button11.TabIndex = 29;
            this.Button11.UseVisualStyleBackColor = true;
            this.Button11.Click += new System.EventHandler(this.Button11_Click);
            // 
            // Button12
            // 
            this.Button12.BackgroundImage = global::Hotel_Management_System.Properties.Resources.icon_hotel;
            this.Button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button12.Location = new System.Drawing.Point(36, 51);
            this.Button12.Margin = new System.Windows.Forms.Padding(2);
            this.Button12.Name = "Button12";
            this.Button12.Size = new System.Drawing.Size(88, 84);
            this.Button12.TabIndex = 27;
            this.Button12.UseVisualStyleBackColor = true;
            this.Button12.Click += new System.EventHandler(this.Button12_Click);
            // 
            // Button17
            // 
            this.Button17.BackgroundImage = global::Hotel_Management_System.Properties.Resources._38650_200;
            this.Button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button17.Location = new System.Drawing.Point(633, 56);
            this.Button17.Margin = new System.Windows.Forms.Padding(2);
            this.Button17.Name = "Button17";
            this.Button17.Size = new System.Drawing.Size(88, 84);
            this.Button17.TabIndex = 31;
            this.Button17.UseVisualStyleBackColor = true;
            this.Button17.Click += new System.EventHandler(this.Button17_Click);
            // 
            // Button15
            // 
            this.Button15.BackgroundImage = global::Hotel_Management_System.Properties.Resources.flat_56_512;
            this.Button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button15.Location = new System.Drawing.Point(346, 56);
            this.Button15.Margin = new System.Windows.Forms.Padding(2);
            this.Button15.Name = "Button15";
            this.Button15.Size = new System.Drawing.Size(88, 84);
            this.Button15.TabIndex = 29;
            this.Button15.UseVisualStyleBackColor = true;
            this.Button15.Click += new System.EventHandler(this.Button15_Click);
            // 
            // Button16
            // 
            this.Button16.BackgroundImage = global::Hotel_Management_System.Properties.Resources._14_vegetable_512;
            this.Button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button16.Location = new System.Drawing.Point(36, 51);
            this.Button16.Margin = new System.Windows.Forms.Padding(2);
            this.Button16.Name = "Button16";
            this.Button16.Size = new System.Drawing.Size(88, 84);
            this.Button16.TabIndex = 27;
            this.Button16.UseVisualStyleBackColor = true;
            this.Button16.Click += new System.EventHandler(this.Button16_Click);
            // 
            // Button9
            // 
            this.Button9.BackgroundImage = global::Hotel_Management_System.Properties.Resources.money_icon;
            this.Button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button9.Location = new System.Drawing.Point(346, 48);
            this.Button9.Margin = new System.Windows.Forms.Padding(2);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(88, 84);
            this.Button9.TabIndex = 25;
            this.Button9.UseVisualStyleBackColor = true;
            this.Button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // Button7
            // 
            this.Button7.BackgroundImage = global::Hotel_Management_System.Properties.Resources.download;
            this.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button7.Location = new System.Drawing.Point(35, 48);
            this.Button7.Margin = new System.Windows.Forms.Padding(2);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(88, 84);
            this.Button7.TabIndex = 21;
            this.Button7.UseVisualStyleBackColor = true;
            this.Button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // Button6
            // 
            this.Button6.BackgroundImage = global::Hotel_Management_System.Properties.Resources._38_384151_clipart_resolution_980912_online_check_in_icon_png;
            this.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button6.Location = new System.Drawing.Point(496, 188);
            this.Button6.Margin = new System.Windows.Forms.Padding(2);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(88, 84);
            this.Button6.TabIndex = 24;
            this.Button6.UseVisualStyleBackColor = true;
            this.Button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // Button5
            // 
            this.Button5.BackgroundImage = global::Hotel_Management_System.Properties.Resources.calendar_512;
            this.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button5.Location = new System.Drawing.Point(184, 188);
            this.Button5.Margin = new System.Windows.Forms.Padding(2);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(90, 84);
            this.Button5.TabIndex = 23;
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // customersBindingNavigatorSaveItem
            // 
            this.customersBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.customersBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("customersBindingNavigatorSaveItem.Image")));
            this.customersBindingNavigatorSaveItem.Name = "customersBindingNavigatorSaveItem";
            this.customersBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.customersBindingNavigatorSaveItem.Text = "Save Data";
            this.customersBindingNavigatorSaveItem.Click += new System.EventHandler(this.customersBindingNavigatorSaveItem_Click);
            // 
            // pnlEmpInfo
            // 
            this.pnlEmpInfo.Controls.Add(this.label16);
            this.pnlEmpInfo.Controls.Add(this.sTAFFDataGridView);
            this.pnlEmpInfo.Location = new System.Drawing.Point(151, 162);
            this.pnlEmpInfo.Name = "pnlEmpInfo";
            this.pnlEmpInfo.Size = new System.Drawing.Size(1190, 536);
            this.pnlEmpInfo.TabIndex = 12;
            this.pnlEmpInfo.Visible = false;
            // 
            // staffTableAdapter1
            // 
            this.staffTableAdapter1.ClearBeforeFill = true;
            // 
            // sTAFFBindingSource
            // 
            this.sTAFFBindingSource.DataMember = "STAFF";
            this.sTAFFBindingSource.DataSource = this.hotel_ResourcesDataSet2;
            // 
            // sTAFFTableAdapter
            // 
            this.sTAFFTableAdapter.ClearBeforeFill = true;
            // 
            // sTAFFDataGridView
            // 
            this.sTAFFDataGridView.AutoGenerateColumns = false;
            this.sTAFFDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sTAFFDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38});
            this.sTAFFDataGridView.DataSource = this.sTAFFBindingSource;
            this.sTAFFDataGridView.Location = new System.Drawing.Point(219, 97);
            this.sTAFFDataGridView.Name = "sTAFFDataGridView";
            this.sTAFFDataGridView.Size = new System.Drawing.Size(745, 430);
            this.sTAFFDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn32.HeaderText = "ID";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn33.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn34.HeaderText = "LastName";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "Type";
            this.dataGridViewTextBoxColumn35.HeaderText = "Type";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn36.HeaderText = "Position";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "Username";
            this.dataGridViewTextBoxColumn37.HeaderText = "Username";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "PWord";
            this.dataGridViewTextBoxColumn38.HeaderText = "PWord";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(524, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(180, 29);
            this.label16.TabIndex = 1;
            this.label16.Text = "Employee Info";
            // 
            // pnlFAQ
            // 
            this.pnlFAQ.Controls.Add(this.richTextBox2);
            this.pnlFAQ.Controls.Add(this.label18);
            this.pnlFAQ.Controls.Add(this.label17);
            this.pnlFAQ.Location = new System.Drawing.Point(151, 164);
            this.pnlFAQ.Name = "pnlFAQ";
            this.pnlFAQ.Size = new System.Drawing.Size(1064, 546);
            this.pnlFAQ.TabIndex = 12;
            this.pnlFAQ.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(365, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(341, 29);
            this.label17.TabIndex = 0;
            this.label17.Text = "Frequently Asked Questions";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(327, 58);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(412, 15);
            this.label18.TabIndex = 1;
            this.label18.Text = "As Lobby Clerk, Use This to Answer Guests\' Common Questions";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(170, 92);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(750, 313);
            this.richTextBox2.TabIndex = 2;
            this.richTextBox2.Text = "";
            // 
            // financesDataGridView
            // 
            this.financesDataGridView.AutoGenerateColumns = false;
            this.financesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.financesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn39,
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn42,
            this.dataGridViewTextBoxColumn43,
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45,
            this.dataGridViewTextBoxColumn46,
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49});
            this.financesDataGridView.DataSource = this.financesBindingSource;
            this.financesDataGridView.Location = new System.Drawing.Point(92, 99);
            this.financesDataGridView.Name = "financesDataGridView";
            this.financesDataGridView.Size = new System.Drawing.Size(1000, 220);
            this.financesDataGridView.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "Revenue";
            this.dataGridViewTextBoxColumn39.HeaderText = "Revenue";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "Salaries";
            this.dataGridViewTextBoxColumn40.HeaderText = "Salaries";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.DataPropertyName = "Rent";
            this.dataGridViewTextBoxColumn41.HeaderText = "Rent";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.DataPropertyName = "Electricity";
            this.dataGridViewTextBoxColumn42.HeaderText = "Electricity";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.DataPropertyName = "Water";
            this.dataGridViewTextBoxColumn43.HeaderText = "Water";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.DataPropertyName = "Gas";
            this.dataGridViewTextBoxColumn44.HeaderText = "Gas";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.DataPropertyName = "ISP";
            this.dataGridViewTextBoxColumn45.HeaderText = "ISP";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.DataPropertyName = "Inventory_B";
            this.dataGridViewTextBoxColumn46.HeaderText = "Inventory_B";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.DataPropertyName = "Inventory_R";
            this.dataGridViewTextBoxColumn47.HeaderText = "Inventory_R";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.DataPropertyName = "Other";
            this.dataGridViewTextBoxColumn48.HeaderText = "Other";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.DataPropertyName = "Income";
            this.dataGridViewTextBoxColumn49.HeaderText = "Income";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            // 
            // MainHub
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ClientSize = new System.Drawing.Size(1370, 772);
            this.Controls.Add(this.pnlManager);
            this.Controls.Add(this.pnlLobbyCl);
            this.Controls.Add(this.pnlAdmin);
            this.Controls.Add(this.pnlRestaraunt);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Button6);
            this.Controls.Add(this.Button5);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlUserInfo);
            this.Controls.Add(this.pnlSchedule);
            this.Controls.Add(this.customersBindingNavigator);
            this.Controls.Add(this.pnlMenu);
            this.Controls.Add(this.pnlInventory);
            this.Controls.Add(this.pnlCheck);
            this.Controls.Add(this.pnlRestReservation);
            this.Controls.Add(this.pnlReservations);
            this.Controls.Add(this.pnlAnnouncements);
            this.Controls.Add(this.pnlPay);
            this.Controls.Add(this.pnlEmpInfo);
            this.Controls.Add(this.pnlFAQ);
            this.Controls.Add(this.pnlFinances);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MainHub";
            this.Text = "MainHub";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainHub_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlManager.ResumeLayout(false);
            this.pnlManager.PerformLayout();
            this.pnlRestaraunt.ResumeLayout(false);
            this.pnlRestaraunt.PerformLayout();
            this.pnlAdmin.ResumeLayout(false);
            this.pnlAdmin.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.pnlCheck.ResumeLayout(false);
            this.pnlCheck.PerformLayout();
            this.pnlUserInfo.ResumeLayout(false);
            this.pnlUserInfo.PerformLayout();
            this.pnlSchedule.ResumeLayout(false);
            this.pnlSchedule.PerformLayout();
            this.pnlAddSchedule.ResumeLayout(false);
            this.pnlAddSchedule.PerformLayout();
            this.pnlAnnouncements.ResumeLayout(false);
            this.pnlAnnouncements.PerformLayout();
            this.pnlReservations.ResumeLayout(false);
            this.pnlReservations.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customer_InfoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingNavigator)).EndInit();
            this.customersBindingNavigator.ResumeLayout(false);
            this.customersBindingNavigator.PerformLayout();
            this.pnlPay.ResumeLayout(false);
            this.pnlPay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.billBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billDataGridView)).EndInit();
            this.pnlMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.menuDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurant_ResorucesDataSet)).EndInit();
            this.pnlInventory.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.inventoryDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).EndInit();
            this.pnlRestReservation.ResumeLayout(false);
            this.pnlRestReservation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reservationsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationsDataGridView)).EndInit();
            this.pnlLobbyCl.ResumeLayout(false);
            this.pnlLobbyCl.PerformLayout();
            this.pnlFinances.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.financesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotel_ResourcesDataSet2)).EndInit();
            this.pnlEmpInfo.ResumeLayout(false);
            this.pnlEmpInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sTAFFBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTAFFDataGridView)).EndInit();
            this.pnlFAQ.ResumeLayout(false);
            this.pnlFAQ.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.financesDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Panel Panel4;
        internal System.Windows.Forms.Panel pnlManager;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Button Button9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Panel panel2;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Button Button19;
        internal System.Windows.Forms.Panel panel3;
        internal System.Windows.Forms.Panel pnlRestaraunt;
        internal System.Windows.Forms.Label Label22;
        internal System.Windows.Forms.Button Button17;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Button Button15;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.Button Button16;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Panel Panel8;
        internal System.Windows.Forms.Panel pnlAdmin;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.Button Button18;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.Panel Panel9;
        private System.Windows.Forms.Panel pnlCheck;
        private System.Windows.Forms.Label CheckTime;
        private System.Windows.Forms.Panel pnlUserInfo;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel pnlSchedule;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Panel pnlAddSchedule;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel pnlAnnouncements;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel pnlReservations;
        private Customer_InfoDataSet customer_InfoDataSet;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private Customer_InfoDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private Customer_InfoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator customersBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton customersBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView customersDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.TextBox roomTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Panel pnlPay;
        private Customer_InfoDataSetTableAdapters.BillTableAdapter billTableAdapter;
        private System.Windows.Forms.BindingSource billBindingSource;
        private System.Windows.Forms.TextBox lastNameTextBox1;
        private System.Windows.Forms.TextBox firstNameTextBox1;
        private System.Windows.Forms.DataGridView billDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Panel pnlMenu;
        private Restaurant_ResorucesDataSet restaurant_ResorucesDataSet;
        private System.Windows.Forms.BindingSource menuBindingSource;
        private Restaurant_ResorucesDataSetTableAdapters.MenuTableAdapter menuTableAdapter;
        private Restaurant_ResorucesDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView menuDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private Restaurant_ResorucesDataSetTableAdapters.InventoryTableAdapter inventoryTableAdapter;
        private System.Windows.Forms.Panel pnlInventory;
        private System.Windows.Forms.BindingSource inventoryBindingSource;
        private Restaurant_ResorucesDataSetTableAdapters.ReservationsTableAdapter reservationsTableAdapter;
        private System.Windows.Forms.DataGridView inventoryDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.Panel pnlRestReservation;
        private System.Windows.Forms.BindingSource reservationsBindingSource;
        private System.Windows.Forms.DataGridView reservationsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.TextBox lastNameTextBox2;
        private System.Windows.Forms.TextBox firstNameTextBox2;
        internal System.Windows.Forms.Panel Panel6;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Button Button12;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Button Button11;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Panel pnlLobbyCl;
        private System.Windows.Forms.Panel pnlFinances;
        private Hotel_ResourcesDataSet2 hotel_ResourcesDataSet2;
        private System.Windows.Forms.BindingSource financesBindingSource;
        private Hotel_ResourcesDataSet2TableAdapters.FinancesTableAdapter financesTableAdapter;
        private Hotel_ResourcesDataSet2TableAdapters.TableAdapterManager tableAdapterManager2;
        private System.Windows.Forms.Panel pnlEmpInfo;
        private Hotel_ResourcesDataSet1TableAdapters.STAFFTableAdapter staffTableAdapter1;
        private System.Windows.Forms.BindingSource sTAFFBindingSource;
        private Hotel_ResourcesDataSet2TableAdapters.STAFFTableAdapter sTAFFTableAdapter;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridView sTAFFDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.Panel pnlFAQ;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridView financesDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
    }
}